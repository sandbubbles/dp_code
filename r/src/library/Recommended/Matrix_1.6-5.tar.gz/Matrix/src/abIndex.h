#ifndef MATRIX_ABINDEX_H
#define MATRIX_ABINDEX_H

#include <Rinternals.h>

SEXP Matrix_rle_i(SEXP, SEXP);
SEXP Matrix_rle_d(SEXP, SEXP);

#endif /* MATRIX_ABINDEX_H */


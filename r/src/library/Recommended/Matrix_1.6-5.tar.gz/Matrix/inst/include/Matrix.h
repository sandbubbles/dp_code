/* For backwards compatibility only.  Packages should start using */
/* LinkingTo: Matrix (>= 1.6-2) and #include <Matrix/Matrix.h>.   */
#include <R_ext/Visibility.h>
#include "Matrix/Matrix.h"
